# Mathematics of Neural Network

This code is part of my post on **[medium](https://medium.com/@omaraflak/math-neural-network-from-scratch-in-python-d6da9f29ce65)**.

It shows how to create a neural network **from scratch** in **Python**, going all the way from the **mathamatics** to the code.

# Run it

```shell
python example_xor.py
python example_conv.py
python example_mnist.py
```
